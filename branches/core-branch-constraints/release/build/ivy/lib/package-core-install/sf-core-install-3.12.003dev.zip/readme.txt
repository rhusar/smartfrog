/** (C) Copyright 1998-2004 Hewlett-Packard Development Company, LP

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

For more information: www.smartfrog.org

*/

Note: <SF> = 'smartfrog' directory

Where to start:

- Web site: www.smartfrog.org

- User manual: <SF>/dist/docs/sfUserManual.pdf

- Reference manual: <SF>/dist/docs/sfReferenceManual.pdf
   
- Java docs: <SF>/dist/docs/jdocs/index.html

- Examples: <SF>/dist/src/org/smartfrog/examples/examples.html

- Dynamic Web Server Example: <SF>/dist/docs/sfDynamicWebServerExample.pdf

- Build process: <SF>/docs/build.html (only in _ALL distribution)

