package org.smartfrog.services.anubis.partition.util;

public class ConfigException extends Exception {
    public ConfigException(String str) {
        super(str);
    }
}
