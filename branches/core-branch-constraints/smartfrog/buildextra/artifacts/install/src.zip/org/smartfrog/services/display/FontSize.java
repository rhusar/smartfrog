package org.smartfrog.services.display;

/**
 * Created by IntelliJ IDEA.
 * User: julgui
 * Date: 29-Nov-2006
 * Time: 21:25:18
 * To change this template use File | Settings | File Templates.
 */
public interface FontSize {
    void setFontSize(int fontSize);

    void increaseFontSize();

    void reduceFontSize();
}
