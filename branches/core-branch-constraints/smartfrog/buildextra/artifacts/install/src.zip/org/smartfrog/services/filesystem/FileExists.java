package org.smartfrog.services.filesystem;

import org.smartfrog.sfcore.workflow.conditional.Condition;

/**

 */
public interface FileExists extends Condition {

    /**
     * {@value}
     */
    String ATTR_MIN_SIZE="minSize";

}
