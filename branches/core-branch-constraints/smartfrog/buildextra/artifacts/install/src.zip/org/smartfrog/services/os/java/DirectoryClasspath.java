package org.smartfrog.services.os.java;

/**
 */
public interface DirectoryClasspath extends Classpath {

    public static final String ATTR_DIRECTORY="directory";

    public static final String ATTR_RECURSIVE="recursive";

    public static final String ATTR_EARLY="earlyBind";
}
