/** (C) Copyright 1998-2004 Hewlett-Packard Development Company, LP

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

For more information: www.smartfrog.org

*/

package org.smartfrog.examples.pong;


/**
 * Defines the different utility values and key values for pong game.
 */ 
public class Util {
    /** Interger value for chocMou. */
    static int chocMou = 1;
    /** Interger value for chocElastique. */
    static int chocElastique = 0;
    /** Integer valuse for trace. */
    static int trace = 0;
    /** Integer value for Horizontal Bounce . */
    static int BounceHorizontal = 0;
    /** Integer value for Vertical Bounce . */
    static int BounceVertical = 1;
    /** Integer value for collison in x axis. */
    static int XAxisCollision = 0;
    /** Integer value for collision in y axis. */
    static int YAxisCollision = 1;
    /** Key value for up key. */ 
    static int keyUp = 1;
    /** Key value for down key. */ 
    static int keyDown = 2;
    /** Key value for left key. */ 
    static int keyLeft = 3;
    /** Key value for right key. */ 
    static int keyRight = 4;

    /**
     * Util method.
     */ 
    public Util() {
    }
}
