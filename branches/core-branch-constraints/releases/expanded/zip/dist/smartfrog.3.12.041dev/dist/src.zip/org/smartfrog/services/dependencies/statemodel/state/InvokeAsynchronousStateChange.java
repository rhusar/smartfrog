package org.smartfrog.services.dependencies.statemodel.state;

public interface InvokeAsynchronousStateChange {
	public void actOn(State sc);
}
