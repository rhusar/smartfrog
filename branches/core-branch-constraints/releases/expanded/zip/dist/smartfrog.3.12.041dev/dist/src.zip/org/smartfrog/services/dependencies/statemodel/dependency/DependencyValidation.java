package org.smartfrog.services.dependencies.statemodel.dependency;

public interface DependencyValidation {
   public String getTransition();
   public boolean isEnabled();
}
